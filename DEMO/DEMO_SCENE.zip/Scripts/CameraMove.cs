﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraMove : MonoBehaviour {


	// Update is called once per frame
	void Update ()
    {
        if (Input.GetKeyDown(KeyCode.R)) 
        {
            transform.position = new Vector3(0, 0, 10);
        }

        if (Input.GetAxis("Mouse ScrollWheel") > 0f) // forward
        {
            transform.position += Vector3.forward;
        }
        else if (Input.GetAxis("Mouse ScrollWheel") < 0f) // backwards
        {
            transform.position -= Vector3.forward;
        }
    }
}
